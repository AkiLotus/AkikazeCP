#include<bits/stdc++.h>
using namespace std;

int main()
{
	string s;
	int k, b, m;
	cin >> s >> k >> b >> m;
	int removal[10];
	for (int i=0; i<10; i++) {
		removal[i] = i % ;
		for (int j=1;)
	}
	return 0;
}

