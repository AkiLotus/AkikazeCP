#include<bits/stdc++.h>
using namespace std;

bool visited[8000000];
int dp[8000000];
vector<int> adj[8000000];
int init, dest;
int ftrl[10] = {1, 1, 2, 6, 24, 120, 720, 5040, 40320, 362880};
int def[] = {1, 2, 3, 8, 0, 0, 4, 7, 6, 5};

int generateCode(int insignia[10]) {
	int pp[] = {0, 0, 1, 2, 3, 4, 5, 6, 7, 8};
	vector<int> arsenal (pp, pp+10);
	int result = 0;
	for (int i=0; i<10; i++) {
		int z = find(arsenal.begin(), arsenal.end(), insignia[i]) - arsenal.begin();
		result += z * ftrl[9-i];
		arsenal.erase(arsenal.begin()+z);
	}
	return result;
}

void generateGraph(int insignia[10], int code) {
	//cout << "bug spotting... - working at " << code << endl;
	int tmp1[10], tmp2[10];
	for (int i=0; i<10; i++) {
		tmp1[i] = insignia[i]; tmp2[i] = insignia[i];
	}
	int swap1 = tmp1[0], swap2 = tmp1[1], swap3 = tmp1[3], swap4 = tmp1[5], swap5 = tmp1[7], swap6 = tmp1[8];
	tmp1[0] = swap3; tmp1[1] = swap1; tmp1[3] = swap5; tmp1[5] = swap2; tmp1[7] = swap6; tmp1[8] = swap4;
	swap1 = tmp2[1], swap2 = tmp2[2], swap3 = tmp2[4], swap4 = tmp2[6], swap5 = tmp2[8], swap6 = tmp2[9];
	tmp2[1] = swap3; tmp2[2] = swap1; tmp2[4] = swap5; tmp2[6] = swap2; tmp2[8] = swap6; tmp2[9] = swap4;
	int pos1 = generateCode(tmp1), pos2 = generateCode(tmp2);
	if (find(adj[code].begin(), adj[code].end(), pos1) == adj[code].end()) {
		adj[code].push_back(pos1);
		generateGraph(tmp1, pos1);
	}
	if (find(adj[code].begin(), adj[code].end(), pos2) == adj[code].end()) {
		adj[code].push_back(pos2);
		generateGraph(tmp2, pos2);
	}
}

int main()
{
	int hex[10];
	for (int i=0; i<10; i++) cin >> hex[i];
	init = generateCode(hex);
	dest = generateCode(def);
	generateGraph(hex, init);
	queue<int> Q;
	if (init != dest) Q.push(init);
	while (!Q.empty()) {
		int z = Q.front(); Q.pop();
		if (visited[z]) continue;
		visited[z] = true;
		for (int i=0; i<adj[z].size(); i++) {
			if (!visited[adj[z][i]]) {
				if (dp[adj[z][i]] == 0) dp[adj[z][i]] = dp[z] + 1;
				else dp[adj[z][i]] = min(dp[adj[z][i]], dp[z] + 1);
				Q.push(adj[z][i]);
			}
		}
	}
	cout << dp[dest];
	return 0;
}

